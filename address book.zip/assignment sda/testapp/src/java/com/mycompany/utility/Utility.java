/*
 * Utility.java
 *
 * Created on February 27, 2007, 5:54 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.mycompany.utility;

/**
 *
 * @author 05030056
 */
public class Utility {
    
    /** Creates a new instance of Utility */
    public Utility() {
    }
    
    public static void removeSpecialChar(String s)
    {
        
    }
    
}
