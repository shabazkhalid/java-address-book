/*
 * Constants.java
 *
 * Created on February 27, 2007, 5:56 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.mycompany.utility;

/**
 *
 * @author 05030056
 */
public interface Constants {
    String REC_NOT_FOUND = "Record not found";
}
