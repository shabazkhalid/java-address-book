/*
 * PersonDao.java
 *
 * Created on February 27, 2007, 5:44 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.mycompany.dao;

import com.mycompany.dto.PersonDto;
import com.mycompany.dto.ResponseDto;
import com.mycompany.utility.Logger;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author 05030056
 */
public class PersonDao extends AbstractDao {
    public PersonDao() throws Exception{
        con = getConnection();
    }
    
    
    
    public ResponseDto searchPerson(PersonDto p) throws Exception {
        
        try {
            
            ResponseDto r  = new ResponseDto();
            // search query based on name only, 
            // to do ... search based on name and address
            String sql ="SELECT * FROM Person where name1 like ?";
            
            PreparedStatement pStmt = con.prepareStatement(
                    sql,
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE
                    );
            
            String n    = "%" + p.getName() + "%";
            
            pStmt.setString(1, n);
            
            ResultSet rs = pStmt.executeQuery( );
            
            ArrayList contacts = new ArrayList();
            
            while(rs.next()) {
                
                PersonDto p1 = new PersonDto();
                
                p1.setName(rs.getString("name1"));
                p1.setAddress(rs.getString("address"));
                
                contacts.add(p1); 
            }
            r.setData(contacts);
            releaseResources();
            return r;
        }catch(Exception e) {
            Logger.logException(e, "exception while searching");
            throw e;
        }

    }
    
    public void addPerson(PersonDto p) throws Exception {
        try{
            //do your sql and return response dto
            String query="INSERT INTO Person(name1, address) VALUES(' " +
                    p.getName() + "' , '" + p.getAddress() + "') ";
            Statement  stmt  = con.createStatement(); 
            int num 	     = stmt.executeUpdate(query);            
            releaseResources();
            
        }catch(Exception e) {
            Logger.logException(e, "exception while adding new contact");
            throw e;
        }
    }
    public void editPerson(PersonDto p) throws Exception {
        
        System.out.println(p.getName()+p.getAddress());
                
      

        
        try {

  String query = "UPDATE Person SET address = "+"'"+p.getAddress()+"'"+ "WHERE  name1 LIKE "+"'"+"%"+p.getName()+"'";
  
          System.out.println(query);

  /*SELECT Surname
   FROM Contacts
   WHERE Surname LIKE 'Mc%';*/

      PreparedStatement preparedStmt = con.prepareStatement(query);
     // preparedStmt.setInt   (1, 6000);
     // preparedStmt.setString(2, "Fred");

      // execute the java preparedstatement
      preparedStmt.executeUpdate();
      
      con.close();
        
        
        
        
        }
        catch(Exception e) {
            Logger.logException(e, "exception while adding new contact");
            throw e;
        }
        
        
        
        
        
        
        
      /*try{
            //do your sql and return response dto
            System.out.println("edit in dao");
            System.out.println(p.getName());
            System.out.println(p.getAddress());
       */     
            /*String sql ="SELECT * FROM Person where name1 like ?";
            System.out.println("edit in dao in 1");
            PreparedStatement pStmt = con.prepareStatement(
                    sql,
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE
                    );
            
            String n    = "%" + p.getName() + "%";
             System.out.println("edit in dao in 2");
            pStmt.setString(1, n);
             System.out.println("edit in dao in 3");
            ResultSet rs = pStmt.executeQuery( );
             System.out.println("edit in dao in 4");
             System.out.println(rs);
            while(rs.next()) {
                System.out.println(rs.getString("name1"));
                System.out.println(rs.getString("address"));
            }

            con.setAutoCommit(false); 
            while(rs.next()) {
                rs.updateString(rs.getString("address"), p.getAddress());
                rs.updateRow();
            }

            con.commit();*/
            
        /*    String query="UPDATE Person set address = ? WHERE name1 = '"+p.getName()+"' ";
            System.out.println(query);
        */    
          /*  Statement  stmt  = con.createStatement();
            System.out.println("edit 2 in dao");
                        
            int num 	     = stmt.executeUpdate(query); 
            //System.out.println("num = " + num);
           System.out.println("end of edit in dao");
           */ 
            /*PreparedStatement pStmt = con.prepareStatement(
                    query,
                    ResultSet.TYPE_FORWARD_ONLY, 
                    ResultSet.CONCUR_UPDATABLE, 
                    ResultSet.CLOSE_CURSORS_AT_COMMIT
                    );
            */
            //String n    = "%" + p.getName() + "%";
            
           // pStmt.setString(1, n);
          /*  PreparedStatement pStmt = con.prepareStatement(query);
            pStmt.setString(1, p.getAddress());   
            pStmt.executeUpdate( );
            
            
           releaseResources();
           System.out.println("end of edit in dao");
            
        }catch(Exception e) {
            Logger.logException(e, "exception while adding new contact");
            throw e;
        }*/
    }
    
    public void deletePerson(PersonDto p) throws Exception {
        try{
            
                      System.out.println(p.getName());

            //delete from [table name] where [column name] like '%[text to find]%'
       String query = "DELETE FROM Person WHERE name1 like "  +"'"+"%"+p.getName()+"'"  ;
  
          System.out.println(query);

  /*SELECT Surname
   FROM Contacts
   WHERE Surname LIKE 'Mc%';*/

      PreparedStatement preparedStmt = con.prepareStatement(query);
     // preparedStmt.setInt   (1, 6000);
     // preparedStmt.setString(2, "Fred");

      // execute the java preparedstatement
      preparedStmt.executeUpdate();
      
      con.close();
        
        
        //name1= "+"'"+"%"+p.getName()+"'"
        
        }catch(Exception e) {
            Logger.logException(e, "exception while adding new contact");
            throw e;
        }
    }
}

