/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.dao;

import com.mycompany.dto.AppointmentDto;
import com.mycompany.dto.ResponseDto;
import com.mycompany.utility.Logger;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author shabaz
 */
public class AppointmentDao extends AbstractDao{
    
    
    public AppointmentDao() throws Exception{
        con = getConnection();
    }
    
    
    public ResponseDto searchAppointment(AppointmentDto p) throws Exception {
        
        try {
            
            ResponseDto r  = new ResponseDto();
            // search query based on name only, 
            // to do ... search based on name and address
            String sql ="SELECT * FROM appointment where apptitle like ?";
            
            PreparedStatement pStmt = con.prepareStatement(
                    sql,
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE
                    );
            
            String n    = "%" + p.getatitle() + "%";
            
            pStmt.setString(1, n);
            
            ResultSet rs = pStmt.executeQuery( );
            
            ArrayList contacts = new ArrayList();
            
            while(rs.next()) {
                
                AppointmentDto p1 = new AppointmentDto();
                
                p1.setatitle(rs.getString("apptitle"));
                p1.setades(rs.getString("appdes"));
                p1.setadate(rs.getString("appdate"));

                
                contacts.add(p1); 
            }
            r.setData(contacts);
            releaseResources();
            return r;
        }catch(Exception e) {
            Logger.logException(e, "exception while searching");
            throw e;
        }

    }
    
    public void addAppointment(AppointmentDto p) throws Exception {
        try{
            //do your sql and return response dto
            String query="INSERT INTO appointment(apptitle,appdes,appdate) VALUES(' " +
                    p.getatitle() + "' , '" + p.getades() +"' , '"+p.getadate()+ "') ";
            Statement  stmt  = con.createStatement(); 
            int num 	     = stmt.executeUpdate(query);            
            releaseResources();
            
        }catch(Exception e) {
            Logger.logException(e, "exception while adding new contact");
            throw e;
        }
    }
    public void editAppointment(AppointmentDto p) throws Exception {
        
        System.out.println(p.getatitle()+p.getades());
                
      

        
        try {

  String query = "UPDATE appointment SET appdes = "+"'"+p.getades()+"'"+","+"appdate="+"'"+p.getadate()+"'"+ "WHERE  apptitle LIKE "+"'"+"%"+p.getatitle()+"'";
  
          System.out.println(query);

  /*SELECT Surname
   FROM Contacts
   WHERE Surname LIKE 'Mc%';*/

      PreparedStatement preparedStmt = con.prepareStatement(query);
     // preparedStmt.setInt   (1, 6000);
     // preparedStmt.setString(2, "Fred");

      // execute the java preparedstatement
      preparedStmt.executeUpdate();
      
      con.close();
        
        
        
        
        }
        catch(Exception e) {
            Logger.logException(e, "exception while adding new contact");
            throw e;
        }
        
        
        
        
        
        
        
      /*try{
            //do your sql and return response dto
            System.out.println("edit in dao");
            System.out.println(p.getName());
            System.out.println(p.getAddress());
       */     
            /*String sql ="SELECT * FROM Person where name1 like ?";
            System.out.println("edit in dao in 1");
            PreparedStatement pStmt = con.prepareStatement(
                    sql,
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE
                    );
            
            String n    = "%" + p.getName() + "%";
             System.out.println("edit in dao in 2");
            pStmt.setString(1, n);
             System.out.println("edit in dao in 3");
            ResultSet rs = pStmt.executeQuery( );
             System.out.println("edit in dao in 4");
             System.out.println(rs);
            while(rs.next()) {
                System.out.println(rs.getString("name1"));
                System.out.println(rs.getString("address"));
            }

            con.setAutoCommit(false); 
            while(rs.next()) {
                rs.updateString(rs.getString("address"), p.getAddress());
                rs.updateRow();
            }

            con.commit();*/
            
        /*    String query="UPDATE Person set address = ? WHERE name1 = '"+p.getName()+"' ";
            System.out.println(query);
        */    
          /*  Statement  stmt  = con.createStatement();
            System.out.println("edit 2 in dao");
                        
            int num 	     = stmt.executeUpdate(query); 
            //System.out.println("num = " + num);
           System.out.println("end of edit in dao");
           */ 
            /*PreparedStatement pStmt = con.prepareStatement(
                    query,
                    ResultSet.TYPE_FORWARD_ONLY, 
                    ResultSet.CONCUR_UPDATABLE, 
                    ResultSet.CLOSE_CURSORS_AT_COMMIT
                    );
            */
            //String n    = "%" + p.getName() + "%";
            
           // pStmt.setString(1, n);
          /*  PreparedStatement pStmt = con.prepareStatement(query);
            pStmt.setString(1, p.getAddress());   
            pStmt.executeUpdate( );
            
            
           releaseResources();
           System.out.println("end of edit in dao");
            
        }catch(Exception e) {
            Logger.logException(e, "exception while adding new contact");
            throw e;
        }*/
    }
    
    public void deleteAppointment(AppointmentDto p) throws Exception {
        try{
            
           
                      System.out.println("IN DELETE APP"+p.getatitle());

            //delete from [table name] where [column name] like '%[text to find]%'
       String query = "DELETE FROM appointment WHERE apptitle like "  +"'"+"%"+p.getatitle()+"'"  ;
  
          System.out.println(query);

  /*SELECT Surname
   FROM Contacts
   WHERE Surname LIKE 'Mc%';*/

      PreparedStatement preparedStmt = con.prepareStatement(query);
     // preparedStmt.setInt   (1, 6000);
     // preparedStmt.setString(2, "Fred");

      // execute the java preparedstatement
      preparedStmt.executeUpdate();
      
      con.close();
        
        
        //name1= "+"'"+"%"+p.getName()+"'"
        
        }catch(Exception e) {
            Logger.logException(e, "exception while adding new contact");
            throw e;
        }
    }
    
}
