/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.translator;

import com.mycompany.dto.AppointmentDto;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author shabaz
 */
public class AppointmentTranslator {
    
       public AppointmentTranslator() {
    }

       public AppointmentDto translateAppointment(HttpServletRequest request) 
    {
                   System.out.println("In Delete"+"aaaa2222++++++++++++"); 

        AppointmentDto p = new AppointmentDto(); 
        p.setatitle((String)request.getParameter("apptitle"));
        p.setades((String)request.getParameter("appdes"));
                p.setadate((String)request.getParameter("appdate"));
                   System.out.println(p.getatitle()); 

        return p;
    }
    
}
