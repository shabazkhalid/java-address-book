/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.handler;

import com.mycompany.dto.AppointmentDto;
import com.mycompany.translator.AppointmentTranslator;
import com.mycompany.bl.AppointmentBl;
import com.mycompany.dto.ResponseDto;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author shabaz
 */
public class AppointmentHandler extends AbstractHandler {
    
     public AppointmentHandler() {
    }
    
     
     public void processRequest(HttpServletRequest request, HttpServletResponse response )throws Exception {
        String actionId = (String)request.getParameter("actionid");
        if(actionId.equals("search")) {
            searchAppointment(request, response);
        } else if(actionId.equals("add")) {
            addAppointment(request, response);
        }else if(actionId.equals("edit")) {
            editAppointment(request, response);
        }
        else if(actionId.equals("delete")) {
            deleteAppointment(request, response);
        }
    }
    
    private void searchAppointment(HttpServletRequest request, HttpServletResponse response ) throws Exception {
        try{
            AppointmentTranslator t = new AppointmentTranslator();
            AppointmentDto p = t.translateAppointment(request);
            AppointmentBl bl = new AppointmentBl();
            ResponseDto r = bl.searchAppointment(p);
            
            HttpSession session = request.getSession();
            
            // store the dto in session for retrieval on jsp page
            // session is a HashMap
            session.setAttribute("contacts",r);
            response.sendRedirect("asearchresults.jsp");
   
            
        } catch(Exception e) {
            //in case of exception redirect to error page
            com.mycompany.utility.Logger.logDebugMessage(""+ e);
            throw e;
        }
    }
    
    
    private void addAppointment(HttpServletRequest request, HttpServletResponse response)throws Exception {
        try{
            
            AppointmentTranslator t = new AppointmentTranslator();
            AppointmentDto p = t.translateAppointment(request);
            AppointmentBl bl = new AppointmentBl();
            bl.addAppointment(p);
            // no exception till this point so redirect to success page
            response.sendRedirect("success.jsp");
        } catch(Exception e) {
            com.mycompany.utility.Logger.logDebugMessage(""+ e);
            throw e;
        }        
    }
     private void editAppointment(HttpServletRequest request, HttpServletResponse response)throws Exception {
        try{
            System.out.println("In edit");
            AppointmentTranslator t = new AppointmentTranslator();
            AppointmentDto p = t.translateAppointment(request);
            AppointmentBl bl = new AppointmentBl();
            //HttpSession session = request.getSession();
            // store the dto in session for retrieval on jsp page
            // session is a HashMap
            //PersonDto person = (PersonDto)session.getAttribute("update");
            bl.editAppointment(p);
            // no exception till this point so redirect to success page
            response.sendRedirect("success.jsp");
        } catch(Exception e) {
            com.mycompany.utility.Logger.logDebugMessage(""+ e);
            throw e;
        }        
    }
     
    private void deleteAppointment(HttpServletRequest request, HttpServletResponse response)throws Exception {
        try{
            System.out.println("In Delete"+"++++++++++++"); 
             
            AppointmentTranslator t = new AppointmentTranslator();
            AppointmentDto p = t.translateAppointment(request);
            
            AppointmentBl bl = new AppointmentBl();
           
            bl.deleteAppointment(p);
            
            
            // no exception till this point so redirect to success page
            response.sendRedirect("success.jsp");
        } catch(Exception e) {
            com.mycompany.utility.Logger.logDebugMessage(""+ e);
            throw e;
        }        
    } 
    
     
     
}
