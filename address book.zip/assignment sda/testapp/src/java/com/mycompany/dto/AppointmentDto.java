/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.dto;

/**
 *
 * @author shabaz
 */
public class AppointmentDto extends AbstractDto {
    
     private String atitle, ades,adate;
     /** Creates a new instance of PersonDto */
    public AppointmentDto() {
    }
    
    public String getatitle() {
        return atitle;
    }
    public void setatitle(String at) {
        this.atitle=at;
    }
    public String getades() {
        return ades;
    }
    
    public void setades(String ad) {
        this.ades=ad;
    }
    
    public String getadate() {
        return adate;
    }
    
    public void setadate(String adt) {
        this.adate=adt;
    }
    
}
