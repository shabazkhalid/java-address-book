/*
 * AbstractDto.java
 *
 * Created on February 27, 2007, 5:38 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.mycompany.dto;

/**
 *
 * @author 05030056
 */
public abstract class AbstractDto {
    
    
}
