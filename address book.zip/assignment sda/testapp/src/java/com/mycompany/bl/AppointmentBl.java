/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.bl;


import com.mycompany.dao.AppointmentDao;
import com.mycompany.dto.AppointmentDto;
import com.mycompany.dto.ResponseDto;
/**
 *
 * @author shabaz
 */
public class AppointmentBl {
    
     public AppointmentBl() {
    }
     
      public ResponseDto searchAppointment(AppointmentDto p) throws Exception
    {
        ResponseDto r ;
        try
        {
        AppointmentDao dao = new AppointmentDao();
        r= dao.searchAppointment(p);
    }
        catch(Exception e)
        {
            throw e;
        }
    
        return r;
        
    }
    
    public void addAppointment(AppointmentDto p) throws Exception 
    {
        try{
            AppointmentDao dao = new AppointmentDao();
            dao.addAppointment(p);
        }
        catch(Exception e)
        {
            throw e;
        }
    }
    
    public void editAppointment(AppointmentDto p) throws Exception 
    {
        try{
            AppointmentDao dao = new AppointmentDao();
            dao.editAppointment(p);
        }
        catch(Exception e)
        {
            throw e;
        }
    }
    public void deleteAppointment(AppointmentDto p) throws Exception 
    {
        try{
            AppointmentDao dao = new AppointmentDao();
            dao.deleteAppointment(p);
        }
        catch(Exception e)
        {
            throw e;
        }
    }
    
}
